ipconfig /release
ipconfig /renew